import SwiftUI

struct ContentView: View {
    
    @State private var input = ""
    @FocusState private var focus: Bool
//var result: Bool
   @State private var checkResult = ""
    var reverseInput = ""
    var body: some View {
        VStack {
         
            TextField ("Input", text: $input).textFieldStyle(.roundedBorder).padding()
                .autocapitalization(. none)
                .onSubmit {
                    let result = PalindromeCheck(input: input)
                    print(result)
                    focus = false
                    checkResult = String(result)
                    }
                .focused($focus)
//                .accentColor(.blue)
            Button("Palindrome Check") {let result = PalindromeCheck(input: input)
                        print(result)
                                focus = false
                 checkResult = String(result)
                
            }.buttonStyle(.borderedProminent)
            if checkResult == "true" {TextField("Check Result", text:$checkResult)
                    .foregroundColor( .green)
                .textFieldStyle(.roundedBorder).padding()}
            else if checkResult == "false" {TextField("Check Result", text:$checkResult)
                    .foregroundColor( .red)
                .textFieldStyle(.roundedBorder).padding()}
                
    
          
        }
        .accentColor(.blue)
    }
}

func PalindromeCheck(input: String) -> Bool {let reverse = input.reversed()
    if String(reverse) == input {
        return true}
    else {return false}
}

